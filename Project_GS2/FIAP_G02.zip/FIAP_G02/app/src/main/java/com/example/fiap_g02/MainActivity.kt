package com.example.fiap_g02

import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import jxl.Workbook
import jxl.write.Label
import jxl.write.WritableWorkbook
import java.io.File
import java.io.IOException
import android.Manifest
import android.content.Intent
import android.widget.Toast
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.formatter.ValueFormatter

class MainActivity : AppCompatActivity() {

lateinit var lineChart: LineChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Botão Dispositivos
        val buttonD: Button = findViewById(R.id.buttonDispositivos)

        buttonD.setOnClickListener {
            val intent = Intent(this, MainDispostivos::class.java)
            startActivity(intent)
        }


        // Verificar permissões
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                1
            )
        }

        // Botão para criar o arquivo XLS
        val buttonCreateXls: Button = findViewById(R.id.buttonExcel)
        buttonCreateXls.setOnClickListener {
            createExcelFile()
        }

        lineChart=findViewById(R.id.line_chart)

        val list:ArrayList<Entry> = ArrayList()

        list.add(Entry(1f, 10f))
        list.add(Entry(2f, 20f))
        list.add(Entry(3f, 30f))
        list.add(Entry(4f, 40f))
        list.add(Entry(5f, 50f))

        val lineDataSet = LineDataSet(list,"")

        lineDataSet.setColors(Color.RED)
        lineDataSet.lineWidth = 2f

        lineDataSet.valueTextColor= Color.WHITE

        listOf(lineChart.xAxis, lineChart.axisLeft, lineChart.axisRight).forEach { axis ->
            axis.textColor = Color.WHITE       // Cor dos números nos eixos
            axis.axisLineColor = Color.WHITE // Cor da linha do eixo
            axis.gridColor = Color.WHITE // Cor das linhas de grade
        }


        // Configurando os rótulos do eixo X
        val labels = listOf("", "Jan", "Feb", "Mar", "Apr", "May") // Nomes personalizados
        val xAxis = lineChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM // Posição no gráfico
        xAxis.granularity = 1f                     // Intervalo fixo entre os rótulos
        xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                return if (index >= 0 && index < labels.size) labels[index] else ""
            }
        }

        val lineData = LineData(lineDataSet)

        lineChart.data = lineData
        lineChart.invalidate()

    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permissão concedida
                createExcelFile()
            } else {
                // Permissão negada
                Toast.makeText(this, "Permissão para acessar o armazenamento foi negada", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createExcelFile() {
        try {
            // Caminho do arquivo
            val dir = File(Environment.getExternalStorageDirectory().absolutePath + "/MyExcelFiles")
            if (!dir.exists()) dir.mkdirs()

            val file = File(dir, "example.xls")

            // Criando o workbook
            val workbook: WritableWorkbook = Workbook.createWorkbook(file)

            // Criando uma aba
            val sheet = workbook.createSheet("Planilha", 0)

            // Adicionando dados à aba
            sheet.addCell(Label(0, 0, "Janeiro"))
            sheet.addCell(Label(1, 0, "Fevereiro"))
            sheet.addCell(Label(2, 0, "Março"))

            sheet.addCell(Label(0, 1, "1"))
            sheet.addCell(Label(1, 1, "2"))
            sheet.addCell(Label(2, 1, "3"))

            // Finalizando o arquivo
            workbook.write()
            workbook.close()

            // Notificar sucesso
            println("Arquivo criado em: ${file.absolutePath}")

        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}



