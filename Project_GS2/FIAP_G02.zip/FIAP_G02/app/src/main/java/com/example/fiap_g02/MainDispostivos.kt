package com.example.fiap_g02

import android.graphics.Color
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.descendants
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate

class MainDispostivos : AppCompatActivity() {

    lateinit var barChart: BarChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_dispostivos)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        barChart=findViewById(R.id.bar_chart)

        val list:ArrayList<BarEntry> = ArrayList()

        list.add(BarEntry(1f, 10f))
        list.add(BarEntry(2f, 20f))
        list.add(BarEntry(3f, 30f))
        list.add(BarEntry(4f, 40f))


        val barDataSet = BarDataSet(list,"")

        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS, 255)

        barDataSet.valueTextColor= Color.WHITE

        listOf(barChart.xAxis, barChart.axisLeft, barChart.axisRight).forEach { axis ->
            axis.textColor = Color.WHITE       // Cor dos números nos eixos
            axis.axisLineColor = Color.WHITE // Cor da linha do eixo
            axis.gridColor = Color.WHITE // Cor das linhas de grade
        }

        // Configurando os rótulos do eixo X
        val labels = listOf("", "Lãmpadas", "Ar Condicionado", "Porta", "TV") // Nomes personalizados
        val xAxis = barChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM // Posição no gráfico
        xAxis.granularity = 1f                     // Intervalo fixo entre os rótulos
        xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val index = value.toInt()
                return if (index >= 0 && index < labels.size) labels[index] else ""
            }
        }

        val barData = BarData(barDataSet)

        barChart.setFitBars(true)

        barChart.data=barData

        barChart.description.text = "Bar Chart"

        barChart.animateY(2000)

    }
}