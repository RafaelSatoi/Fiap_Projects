import 'package:flutter/material.dart';
import 'package:flutter_fiap_1/screens/autenticacao_tela.dart';
import 'package:flutter_fiap_1/screens/telaSecundaria.dart';

class Telaprincipal extends StatefulWidget {
  const Telaprincipal({super.key});

  @override
  State<Telaprincipal> createState() => _TelaprincipalState();
}

class _TelaprincipalState extends State<Telaprincipal> {
  int _counter = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[200],

      body: Stack(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  "O botão foi apertado essa quantidade de vezes"
                ),
                Text(
                  '$_counter',
                )
              ],
            ),
          ),

         Positioned(
          bottom: 20,
          left: 15,
          child: TextButton(
            onPressed: (){
                Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => TelaSecundaria())
              );
            },
            style: TextButton.styleFrom(
              backgroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10)
            ),
            child: Text("Outra página")),
         ),

         Positioned(
          top: 20,
          left: 15,
          child: TextButton(
            onPressed: (){
                Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => AutenticacaoTela())
              );
            },
            style: TextButton.styleFrom(
              backgroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10)
            ),
            child: Text("Voltar")),
         )

          
        ],
          
      ),
        floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter)
    );
  }

  void _incrementCounter(){
    setState(() {
      _counter++;
    });
}

}


