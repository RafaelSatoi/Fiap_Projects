import 'package:flutter/material.dart';
import 'package:flutter_fiap_1/common/myColors.dart';
import 'package:flutter_fiap_1/screens/telaPrincipal.dart';

class AutenticacaoTela extends StatefulWidget {
  const AutenticacaoTela({super.key});

  State<AutenticacaoTela> createState() => _AutenticacaoTelaState();
}

class _AutenticacaoTelaState extends State<AutenticacaoTela> {
  final _formKey = GlobalKey<FormState>();
  String email = '';
  String senha = '';


  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[200],
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Mycolors.rosaTopoGradiente,
                  Mycolors.rosaBaixoGradiente,
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  
                  TextFormField(
                    onChanged: (value) {
                      email = value;
                    },
                    decoration: const InputDecoration(
                      label: Text("E-mail"),
                    ),
                    validator: (String? value) {
                      if (value == null || value.length == 0) {
                        return "O e-mail não pode ser vazio";
                      }

                      if (value.length < 5) {
                        return "O e-mail é muito curto";
                      }

                      if (!value.contains("@")){
                        return "O e-mail não é valido";
                      }

                      return null;
                    },
                  ),

                  const SizedBox(
                    height: 32,
                  ),

                  TextFormField(
                    onChanged: (value) {
                      senha = value;
                    },
                    decoration: const InputDecoration(label: Text("Senha")),
                    obscureText: true,
                    validator: (String? value) {
                      if (value == null || value.length == 0) {
                        return "A senha não pode ser vazio";
                      }

                      return null;
                    },
                  ),

                  const SizedBox(
                    height: 32,
                  ),

                  ElevatedButton(
                    onPressed: () {
                      botaoPrincipalClicado();
                    },
                    child: const Text("Entrar"),
                  ),

                  TextButton(
                    onPressed: () {},
                    child: const Text("Ainda não tem uma conta? Cadastre-se"),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


  botaoPrincipalClicado(){
    if(_formKey.currentState!.validate() && email == "admin@gmail.com" && senha == "123"){
      print("Form válido");
      Navigator.of(context).push(
        MaterialPageRoute(builder: (context) => Telaprincipal())
      );
    }
    else{
      print("Form inválido");
    }
  }


}
