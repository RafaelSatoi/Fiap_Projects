import 'package:flutter/material.dart';
import 'package:flutter_fiap_1/screens/telaPrincipal.dart';

class TelaSecundaria extends StatefulWidget {
  const TelaSecundaria({super.key});

  @override
  State<TelaSecundaria> createState() => _TelaSecundariaState();
}

class _TelaSecundariaState extends State<TelaSecundaria> {
  int _counter = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.pink[200],
      body: Stack(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  "O botão foi apertado essa quantidade de vezes"
                ),
                Text(
                  '$_counter',
                )
              ],
            ),
          ),

         Positioned(
          bottom: 20,
          left: 15,
          child: TextButton(
            onPressed: (){
                Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => Telaprincipal())
              );
            },
            style: TextButton.styleFrom(
              backgroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10)
            ),
            child: Text("Voltar")),
         )

          
        ],
          
      ),
        floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter)

    );
  }

  void _incrementCounter(){
    setState(() {
      _counter--;
    });
}
}