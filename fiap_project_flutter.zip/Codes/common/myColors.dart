import 'package:flutter/material.dart';

class Mycolors {
  static const Color rosaBaixoGradiente = Color.fromARGB(255, 152, 90, 129);

  static const Color rosaTopoGradiente = Color.fromARGB(255, 241, 158, 210);
}