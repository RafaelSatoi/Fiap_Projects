class Modelo1 {
  String id;
  String name;
  String treino;
  String comoFazer;

  String? urlImagem;

  Modelo1({
    required this.id,
    required this.name,
    required this.treino,
    required this.comoFazer,
  });

  Modelo1.fromMap(Map<String, dynamic> map)
      : id = map["id"],
        name = map["name"],
        treino = map["treino"],
        comoFazer = map["comofazer"],
        urlImagem = map["urlImagem"];
}
