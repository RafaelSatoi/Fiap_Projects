import React, { useState, useTransition } from "react";
import {View, Text, TextInput, Button} from "react-native"


import styles from "../Styles/style1";


export default function Tela1({navigation}){


const [email, setEmail] = useState(null)
const [senha, setSenha] = useState(null)

function validationLogin(){
    if(email == "admin@gmail.com" && senha == "123"){
        navigation.navigate('Tela2')
    }
}
    return(
        <View style={styles.general}>
           {/* E-mail */}
           <View style={styles.textinput1}>
                <Text>E-mail</Text>
                <TextInput
                onChangeText={setEmail}
                placeholder="fulano@gmail.com"
                keyboardType="email-address"
                />
           </View>
            
             {/* Senha */}
            <View style={styles.textinput2}>
                <Text>Senha</Text>
                <TextInput
                    onChangeText={setSenha}
                    placeholder="Digite sua senha"
                    secureTextEntry={true} // Certo para mostrar "****"
                />
            </View>

            {/* Botão */}
            <Button 
            onPress={() => validationLogin()}
            title="Entrar"/>

        </View>
    );
}

