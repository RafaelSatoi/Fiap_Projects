import React, { useState, useTransition } from "react";
import {View, Text, TextInput, Button} from "react-native"
import styles from "../Styles/style3"

export default function Tela3({navigation}){

    const [number, setNumber] = useState(0)

    function addNumber(){
        setNumber(number - 1)
    } 

    return(
        <View style={styles.general}>

            <View>
                <Text>{number}</Text>
            </View>
            
            <View style={styles.container_buttons}>

                <View style={styles.button}>
                    <Button
                    onPress={()=> navigation.navigate('Tela2')}
                    title="Anterior"
                    />    
                </View>
                
                <View style={styles.button}>
                    <Button
                    title="-"
                    onPress={addNumber}
                    />  
                </View>
            
            </View>

        </View>
    )
}