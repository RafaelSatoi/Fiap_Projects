import React, { useState, useTransition } from "react";
import {View, Text, TextInput, Button} from "react-native"
import styles from "../Styles/style2"

export default function Tela2({navigation}){

    const [number, setNumber] = useState(0)

    function addNumber(){
        setNumber(number + 1)
    } 

    return(
        <View style={styles.general}>

            <View>
                <Text>{number}</Text>
            </View>
            
            <View style={styles.container_buttons}>

                <View style={styles.button}>
                    <Button
                    onPress={()=> navigation.navigate('Tela1')}
                    title="Sair"
                    />    
                </View>
                
                <View style={styles.button}>
                    <Button
                    title="+"
                    onPress={addNumber}
                    />  
                </View>

                <View style={styles.button}>
                    <Button
                    onPress={()=> navigation.navigate('Tela3')}
                    title="Próximo"
                    />    
                </View>
            
            </View>

        </View>
    )
}