import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
general:{
    height: "100%",
    width: "100%",
    justifyContent: "center",
    padding: "20%",
    backgroundColor: '#e0e5e5',
    
},
textinput1:{
    marginBottom: 30
},
textinput2:{
    marginBottom: 30
}


})

export default styles