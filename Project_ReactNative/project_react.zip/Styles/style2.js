import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    general:{
        height: "100%",
        width: "100%",
        justifyContent: "center",
        padding: "20%",
        backgroundColor: '#e0e5e5',
        justifyContent: "center",
        alignItems: "center"
    },
    container_buttons:{
        marginTop: 300,
        flexDirection: 'row',
    },
    button:{
        margin: 10,
        height: 40,
        width: 100
    },

})

export default styles